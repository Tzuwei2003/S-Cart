package cn.techtutorial.dao;

import java.sql.*;
import cn.techtutorial.model.*;

public class UserDao {
	private Connection con;
	private String query;
    private PreparedStatement pst;
    private ResultSet rs;

	public UserDao(Connection con) {
		super();
		this.con = con;
	}
	
	public User getUserInfo(int userID) {
		User user = new User();
        try {
            query = "select * from users where id=?";
            pst = this.con.prepareStatement(query);
            pst.setInt(1, userID);
            rs = pst.executeQuery();
            
            if (rs.next()){
            	user.setId(rs.getInt("id"));
            	user.setName(rs.getString("name"));
            	user.setEmail(rs.getString("email"));
            	user.setPassword(rs.getString("password"));
            	user.setGender(rs.getString("gender"));
            	user.setHeight(rs.getDouble("height"));
            	user.setWeight(rs.getDouble("weight"));
            	user.setBudget(rs.getInt("budget"));
            	user.setCalLimit(rs.getInt("cal_limit"));
            	user.setAllergy(rs.getString("allergy"));
            	user.setPic(rs.getString("pic"));
            }
        } catch (SQLException e) {
            System.out.print(e.getMessage());
        }
        
        return user;
    }
}