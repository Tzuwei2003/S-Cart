package cn.techtutorial.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cn.techtutorial.connection.DbCon;

/**
 * Servlet implementation class TrackExpenseServlet
 */
@WebServlet("/send-to-modifier")
public class SendToModifierServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public SendToModifierServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)	throws ServletException, IOException {
		HttpSession session = request.getSession();
		
		String paramName = request.getParameterNames().nextElement();
		
		if (paramName.equals("name")) {
			session.setAttribute("itemChanged", "name");
		}else if (paramName.equals("email")) {
			session.setAttribute("itemChanged", "email");
		}else if (paramName.equals("password")) {
			session.setAttribute("itemChanged", "password");
		}else if (paramName.equals("gender")) {
			session.setAttribute("itemChanged", "gender");
		}else if (paramName.equals("height")) {
			session.setAttribute("itemChanged", "height");
		}else if (paramName.equals("weight")) {
			session.setAttribute("itemChanged", "weight");
		}else if (paramName.equals("budget")) {
			session.setAttribute("itemChanged", "budget");
		}else if (paramName.equals("calLimit")) {
			session.setAttribute("itemChanged", "calLimit");
		}else if (paramName.equals("allergy")) {
			session.setAttribute("itemChanged", "allergy");
		}else if (paramName.equals("pic")) {
			session.setAttribute("itemChanged", "pic");
		}
		
		response.sendRedirect("modifier.jsp");
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
