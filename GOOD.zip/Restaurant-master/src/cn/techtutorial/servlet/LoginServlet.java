package cn.techtutorial.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import cn.techtutorial.connection.DbCon;

/**
 * Servlet implementation class Login
 */
@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// fetch email and password from the textarea of "login.jsp"
		String email = request.getParameter("login-email");
		String password = request.getParameter("login-password");
		RequestDispatcher dispatcher = null;
		Connection con = null;
		HttpSession session = request.getSession();

		// connect to database then match the data
		try {
			con = DbCon.getConnection();
			PreparedStatement pst = con.prepareStatement("select * from users where email=? and password=?");
			pst.setString(1, email);
			pst.setString(2, password);

			ResultSet rs = pst.executeQuery();
			if (rs.next()) {
				String userEmail = rs.getString("email");
				int userID = DbCon.setUser(userEmail);
				session.setAttribute("userID", userID);
				
				String identity = DbCon.getIdentity(userEmail);
				
				if (identity.equals("costomer")) {
					String allergy = DbCon.getAllergy(userEmail);
					session.setAttribute("allergy", allergy);
					
					dispatcher = request.getRequestDispatcher("index.jsp");
				}else if (identity.equals("administrator")) {
					dispatcher = request.getRequestDispatcher("rest-form.jsp");
				}
				
				
				
				
				
			} else {
				session.setAttribute("status", "failed");
				dispatcher = request.getRequestDispatcher("login.jsp");
			}
			dispatcher.forward(request, response);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}