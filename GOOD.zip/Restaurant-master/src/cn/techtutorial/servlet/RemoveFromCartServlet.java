package cn.techtutorial.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.techtutorial.connection.DbCon;
import cn.techtutorial.model.Cart;

/**
 * Servlet implementation class RemoveFromCartServlet
 */
@WebServlet("/remove-from-cart")
public class RemoveFromCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");

		int userID = (int) request.getSession().getAttribute("userID");
		String date = (String) request.getSession().getAttribute("date");
		int recordID = Integer.parseInt(request.getParameter("id"));

		Connection con;
		String query;
		PreparedStatement pst;
		ResultSet rs;

		try {
			con = (Connection) DbCon.getConnection();
			// delete old data from 'record'
			query = "delete from record where recordID=?;";
			pst = con.prepareStatement(query);
			pst.setInt(1, recordID);
			pst.executeUpdate();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		response.sendRedirect("cart.jsp");
	}

}
