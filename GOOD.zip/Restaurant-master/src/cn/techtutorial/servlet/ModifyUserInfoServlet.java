package cn.techtutorial.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.techtutorial.connection.DbCon;

/**
 * Servlet implementation class TrackExpenseServlet
 */
@WebServlet("/ModifyUserInfoServlet")
public class ModifyUserInfoServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ModifyUserInfoServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)	throws ServletException, IOException {
		Connection con;
		String query;
		PreparedStatement pst;
		ResultSet rs;
		
		String paramName = request.getParameterNames().nextElement();
		int userID = (int) request.getSession().getAttribute("userID");
		
		if (paramName.equals("name")) {
			String name = request.getParameter("name").toString();
			
			try {
				con = (Connection) DbCon.getConnection();
				query = "update users set name=? where id=?;";
				pst = con.prepareStatement(query);
				pst.setString(1, name);
				pst.setInt(2, userID);
				pst.executeUpdate();	
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if (paramName.equals("email")) {
			String email = request.getParameter("email").toString();
			
			try {
				con = (Connection) DbCon.getConnection();
				query = "update users set email=? where id=?;";
				pst = con.prepareStatement(query);
				pst.setString(1, email);
				pst.setInt(2, userID);
				pst.executeUpdate();	
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if (paramName.equals("password")) {
			String password = request.getParameter("password").toString();
			
			try {
				con = (Connection) DbCon.getConnection();
				query = "update users set password=? where id=?;";
				pst = con.prepareStatement(query);
				pst.setString(1, password);
				pst.setInt(2, userID);
				pst.executeUpdate();	
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if (paramName.equals("gender")) {
			String gender = request.getParameter("gender").toString();

			try {
				con = (Connection) DbCon.getConnection();
				query = "update users set gender=? where id=?;";
				pst = con.prepareStatement(query);
				pst.setString(1, gender);
				pst.setInt(2, userID);
				pst.executeUpdate();	
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if (paramName.equals("height")) {
			double height = Double.parseDouble(request.getParameter("height"));

			try {
				con = (Connection) DbCon.getConnection();
				query = "update users set height=? where id=?;";
				pst = con.prepareStatement(query);
				pst.setDouble(1, height);
				pst.setInt(2, userID);
				pst.executeUpdate();	
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if (paramName.equals("weight")) {
			double weight = Double.parseDouble(request.getParameter("weight"));

			try {
				con = (Connection) DbCon.getConnection();
				query = "update users set weight=? where id=?;";
				pst = con.prepareStatement(query);
				pst.setDouble(1, weight);
				pst.setInt(2, userID);
				pst.executeUpdate();	
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if (paramName.equals("budget")) {
			int budget = Integer.parseInt(request.getParameter("budget"));

			try {
				con = (Connection) DbCon.getConnection();
				query = "update users set budget=? where id=?;";
				pst = con.prepareStatement(query);
				pst.setInt(1, budget);
				pst.setInt(2, userID);
				pst.executeUpdate();	
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if (paramName.equals("calLimit")) {
			int calLimit = Integer.parseInt(request.getParameter("calLimit"));

			try {
				con = (Connection) DbCon.getConnection();
				query = "update users set cal_limit=? where id=?;";
				pst = con.prepareStatement(query);
				pst.setInt(1, calLimit);
				pst.setInt(2, userID);
				pst.executeUpdate();	
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if (paramName.equals("allergy")) {
			String allergy = request.getParameter("allergy").toString();

			try {
				con = (Connection) DbCon.getConnection();
				query = "update users set allergy=? where id=?;";
				pst = con.prepareStatement(query);
				pst.setString(1, allergy);
				pst.setInt(2, userID);
				pst.executeUpdate();	
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else if (paramName.equals("pic")) {
			String pic = request.getParameter("pic").toString();

			try {
				con = (Connection) DbCon.getConnection();
				query = "update users set pic=? where id=?;";
				pst = con.prepareStatement(query);
				pst.setString(1, pic);
				pst.setInt(2, userID);
				pst.executeUpdate();	
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		response.sendRedirect("p_info.jsp");
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
