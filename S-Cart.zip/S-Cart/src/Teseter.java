import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.jsoup.Connection;

import cn.techtutorial.connection.DbCon;
import cn.techtutorial.model.Record;

public class Teseter {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		DbCon.getConnection();
		System.out.println(DbCon.checkUser("jenny@mail.com"));
	}
}

public static void setUser(String email) {
	try {
		String query = "SELECT * FROM users WHERE email=?";;
		PreparedStatement pst = connection.prepareStatement(query);
		pst.setString(1, email);
		ResultSet rs = pst.executeQuery();
		
		if(rs.next()) {
			user.setId(rs.getInt("id"));
			user.setName(rs.getString("name"));
			user.setEmail(rs.getString("email"));
			user.setPassword(rs.getString("password"));
			user.setGender(rs.getString("gender"));
			user.setHeight(rs.getDouble("height"));
			user.setWeight(rs.getInt("weight"));
			user.setBudget(rs.getInt("budget"));
			user.setCalLimit(rs.getInt("cal_limit"));	
		}
	} catch(Exception e) {
		e.printStackTrace();	
	} 
}

public static int getUserID() {
	return user.getId();
}
<%
int userID = (int) request.getSession().getAttribute("userID");
ExpenseRecordDao erd = new ExpenseRecordDao(DbCon.getConnection());
List<ExpenseRecord> ers = erd.getAllExpRcs(userID, "2022-05-03");
%>