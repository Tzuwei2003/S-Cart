package cn.techtutorial.dao;

import java.sql.*;
import java.util.*;
import cn.techtutorial.model.Product;
import cn.techtutorial.model.Record;

public class RecordDao {
	private Connection con;

	private String query;
	private PreparedStatement pst;
	private ResultSet rs;

	public RecordDao(Connection con) {
		super();
		this.con = con;
	}

	public List<Record> getAllRecords(int userID) throws SQLException {
		List<Record> book = new ArrayList<>();

		try {
			query = "select * from record where userID=?";
			pst = this.con.prepareStatement(query);
			pst.setInt(1, userID);
			rs = pst.executeQuery();
			
			while (rs.next()) {
				Record row = new Record();
				row.setRecordID(rs.getInt("recordID"));
				row.setUserID(rs.getInt("userID"));
				row.setFoodID(rs.getInt("foodID"));
				row.setDate(rs.getString("cDate"));
				row.setName(rs.getString("foodName"));
				row.setPrice(rs.getInt("price"));
				row.setCalories(rs.getDouble("calories"));
				row.setCategory(rs.getString("category"));

				book.add(row);
			}
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println(e.getMessage());
		}
	
		return book;
	}
}