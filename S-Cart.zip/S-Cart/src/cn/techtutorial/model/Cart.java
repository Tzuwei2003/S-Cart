package cn.techtutorial.model;

public class Cart extends LouisaMenu{
private int quantity;
	
	public Cart() {
		
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
}
