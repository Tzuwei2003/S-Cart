package cn.techtutorial.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.Connection;

import cn.techtutorial.connection.DbCon;
import cn.techtutorial.model.*;


@WebServlet("/add-to-cart")
public class AddToCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html;charset=UTF-8");
		
		int userID = (int) request.getSession().getAttribute("userID");
		int foodID = Integer.parseInt(request.getParameter("id"));
		
		Record rc = new Record();
		rc.setUserID(userID);
		rc.setDate("2022-05-03");
	    rc.setFoodID(foodID);
	    
		Connection con;
		String query;
		PreparedStatement pst;
		ResultSet rs;
		
	    try {
	    	con = (Connection) DbCon.getConnection();
	    	query = "select name, price, calorie from louisa_menu where id=?";
	        pst = con.prepareStatement(query);
	        pst.setInt(1, foodID);
	        rs = pst.executeQuery();
	        
	        if (rs.next()) {
	        	 rc.setName(rs.getString("name"));
	             rc.setPrice(rs.getInt("price"));
	             rc.setCalories(rs.getDouble("calorie"));
	        }
	        
	        query = "insert into record (userID, foodID, cDate, foodName, price, calories, category) values (?, ?, ?, ?, ?, ?, ?);";
	    	pst = con.prepareStatement(query);
	    	pst.setInt(1, rc.getUserID());
	    	pst.setInt(2, rc.getFoodID());
	    	pst.setString(3, rc.getDate());
	    	pst.setString(4, rc.getName());
	    	pst.setInt(5, rc.getPrice());
	    	pst.setDouble(6, rc.getCalories());
	    	pst.setString(7, "null");
	    	
	    	pst.executeUpdate();	
	    } catch (SQLException e) {
	        System.out.println(e.getMessage());
	    } catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
	    }
	    
        response.sendRedirect("louisa_menu.jsp");
        
            //ArrayList<Cart> cartList = new ArrayList<>();
           
            
            //Cart cm = new Cart();
            //cm.setId(id);
            //cm.setQuantity(1);
            //HttpSession session = request.getSession();
            //ArrayList<Cart> cart_list = (ArrayList<Cart>) request.getSession().getAttribute("cart-list");
           
           // if (cart_list == null) {
               // cartList.add(cm);
                //session.setAttribute("cart-list", cartList);
                //response.sendRedirect("index.jsp");

             //} else {
                //cartList = cart_list;

                //boolean exist = false;
                //for (Cart c : cart_list) {
                //    if (c.getId() == id) {
                 //       exist = true;
                 //       response.sendRedirect("index.jsp");
                 //   }
               // }

              //  if (!exist) {
               //     cartList.add(cm);
               //     response.sendRedirect("index.jsp");
	}

}