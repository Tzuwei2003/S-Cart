package cn.techtutorial.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.techtutorial.connection.DbCon;
import cn.techtutorial.model.Cart;

/**
 * Servlet implementation class RemoveFromLM
 */
@WebServlet("/RemoveFromLM")
public class RemoveFromLM extends HttpServlet {
	private static final long serialVersionUID = 1L;
	  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int userID = (int) request.getSession().getAttribute("userID");
		int foodID = Integer.parseInt(request.getParameter("id"));
		
		Connection con;
		String query;
		PreparedStatement pst;
		try {
			con = (Connection) DbCon.getConnection();
			query = "delete from record where userID=? and foodID=? and cDate=?;";
		    pst = con.prepareStatement(query);
		    pst.setInt(1, userID);
		    pst.setInt(2, foodID);
		    pst.setString(3, "2022-05-03");
		    pst.executeUpdate();
		} catch (SQLException e) {
		    System.out.println(e.getMessage());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		response.sendRedirect("louisa_menu.jsp");
		
		
		
		
		
		
		
		
		
		
		
		
		
		//try(PrintWriter out = response.getWriter()){
		//	String id = request.getParameter("id");
		//	out.println("product id " +id);
			
		//	if(id!= null) {
		//		ArrayList<Cart> cart_list = (ArrayList<Cart>) request.getSession().getAttribute("cart-list");
		//		if(cart_list != null) {
		//			for(Cart c:cart_list) {
		//				if(c.getId()== Integer.parseInt(id)) {
		//					cart_list.remove(cart_list.indexOf(c));
			//				break;
		//				}
		//			}
		//			response.sendRedirect("louisa_menu.jsp");
		//		}
		//	}else {
		//		response.sendRedirect("louisa_menu.jsp");
		//	}
		//}
	}

}
