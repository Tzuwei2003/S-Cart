 package cn.techtutorial.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.techtutorial.connection.DbCon;
import cn.techtutorial.model.Cart;

/**
 * Servlet implementation class RemoveFromCartServlet
 */
@WebServlet("/remove-from-cart")
public class RemoveFromCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
  
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int userID = (int) request.getSession().getAttribute("userID");
		int recordID = Integer.parseInt(request.getParameter("id"));

		Connection con;
		String query;
		PreparedStatement pst;

		try {
			con = (Connection) DbCon.getConnection();
			query = "delete from record where recordID=?;";
		    pst = con.prepareStatement(query);
		    pst.setInt(1, recordID);
		    pst.executeUpdate();
		} catch (SQLException e) {
		    System.out.println(e.getMessage());
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		response.sendRedirect("cart.jsp");
		
		
		//try(PrintWriter out = response.getWriter()){
			//String id = request.getParameter("id");
			//out.println("product id " +id);
			
			//if(id!= null) {
			//	ArrayList<Cart> cart_list = (ArrayList<Cart>) request.getSession().getAttribute("cart-list");
			//	if(cart_list != null) {
			//		for(Cart c:cart_list) {
				//		if(c.getId()== Integer.parseInt(id)) {
			//				cart_list.remove(cart_list.indexOf(c));
			//				break;
				//		}
			//		}
			//		response.sendRedirect("cart.jsp");
			//	}
			//}else {
			//	response.sendRedirect("cart.jsp");
			//}
		//}
	}

}
