package cn.techtutorial.connection;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import cn.techtutorial.model.User;

public class DbCon {

	private static Connection connection = null;

	public static Connection getConnection() throws ClassNotFoundException, SQLException {
		if (connection == null) {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/ecommerce_cart", "root", "20030103");
			System.out.print("connected");
		}
		return connection;
	}

	public static int setUser(String email) {
		int userID = 0;
		try {
			String query = "SELECT id FROM users WHERE email=?";;
			PreparedStatement pst = connection.prepareStatement(query);
			pst.setString(1, email);
			ResultSet rs = pst.executeQuery();
			
			if(rs.next()) {
				userID = rs.getInt("id");	
			}
		} catch(Exception e) {
			e.printStackTrace();	
		}
		
		return userID;
	}
}